import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import { ConnectDb } from "./config/db.js";
import Product from "./model/Product.model.js";

const app=express();
app.use(cors());
app.get('/', (req, res) => {
    res.send('Hello World to everyone!')
  })
  dotenv.config();
  app.use(express.json());

  console.log(process.env.MONGO_URI);



//Post Api call
app.post('/api/products',async(req,res)=>{
  
  const product=req.body;
  if(!product.name ||!product.price||!product.image)
  {
    return res.status(404).json({success:false,message:"Please enter above field"});
  }
const newproduct=new Product(product);
try
{
await newproduct.save();
 res.status(201).json({success:true,data:newproduct});
}
catch(error)
{
  res.status(500).json({success:false,message:'server Error'});


}

})


//GET API CALL

app.get('/api/products',async(req,res)=>{

  try{
  const products=await Product.find({});
  res.status(200).json(products);
  }
  catch(error)
  {
    res.status(404).json({success:false,message:'Records are Empty'});
  }
})



//GET API CALL by Id

app.get('/api/products/:id',async(req,res)=>{

  try{
    const {id}=req.params;
  const products=await Product.findById(id);
  res.status(200).json(products);
  }
  catch(error)
  {
    res.status(500).json({success:false,message:'Records are Empty'});
  }
})

//Delete API CALL by Id

app.delete('/api/products/:id',async(req,res)=>{

  try{
    const {id}=req.params;
  const product=await Product.findByIdAndDelete(id);
  if(!product)
    {
      return res.status(404).json({success:false,message:"Please enter above field"});
    }
  res.status(200).json({messag:"deleted Successfully"});
  }
  catch(error)
  {
    res.status(500).json({success:false,message:'Records are Empty'});
  }
})


//put Api call
app.put('/api/products/:id',async(req,res)=>{

  const {id}=req.params;
  const product=await Product.findByIdAndUpdate(id,req.body);
  if(!product)
  {
    return res.status(404).json({success:false,message:"Please enter above field"});
  }

try
{
  const updatedproduct=await Product.findById(id);

 res.status(200).json({success:true,data:updatedproduct});
}
catch(error)
{
  res.status(500).json({success:false,message:'server Error'});


}

})

app.listen(7000, () => {
  ConnectDb();
    console.log(`Example app listening on port 7000`)
  })



  //npm init -y 
  //npm install i express mongoose dotenv nodemon